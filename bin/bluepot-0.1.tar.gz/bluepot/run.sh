gksudo 'java -jar BluePot.jar'
